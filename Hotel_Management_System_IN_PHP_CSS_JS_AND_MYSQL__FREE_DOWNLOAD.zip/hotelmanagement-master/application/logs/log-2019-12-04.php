<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 16:19:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\hotelmanagement-master\system\core\Common.php 257
ERROR - 2019-12-04 16:19:42 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\hotelmanagement-master\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2019-12-04 16:19:42 --> Unable to connect to the database
ERROR - 2019-12-04 16:20:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\hotelmanagement-master\system\core\Common.php 257
ERROR - 2019-12-04 16:20:35 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\hotelmanagement-master\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2019-12-04 16:20:35 --> Unable to connect to the database
ERROR - 2019-12-04 16:56:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\hotelmanagement-master\system\core\Common.php 257
ERROR - 2019-12-04 16:56:08 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\hotelmanagement-master\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2019-12-04 16:56:08 --> Unable to connect to the database
